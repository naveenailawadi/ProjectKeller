#-*- coding: utf-8 -*-

from .client import Client

__version__ = '2.0.0'